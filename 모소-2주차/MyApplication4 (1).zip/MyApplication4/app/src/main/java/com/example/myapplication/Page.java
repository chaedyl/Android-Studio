package com.example.myapplication;

public class Page {
    public String title;
    public String content;

    public Page(String _title, String _content) {
        title = _title;
        content = _content;
    }
}
