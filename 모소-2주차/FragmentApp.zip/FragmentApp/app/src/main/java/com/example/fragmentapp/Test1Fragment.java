package com.example.fragmentapp;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class Test1Fragment extends Fragment {

    public interface OnTest1ButtonClickedListener {
        void onClick();
    }

    OnTest1ButtonClickedListener mCallback;


    public Test1Fragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof OnTest1ButtonClickedListener) {
            mCallback = (OnTest1ButtonClickedListener)context;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_test1, container, false);
        view.findViewById(R.id.btn_boom).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCallback!= null) {
                    mCallback.onClick();
                }
            }
        });
        return view;
    }

}
