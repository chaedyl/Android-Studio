package com.example.fragmentapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity
        implements Test1Fragment.OnTest1ButtonClickedListener{

    @Override
    public void onClick() {
        Test2Fragment fragment = (Test2Fragment)getSupportFragmentManager()
                .findFragmentById(R.id.article_fragment);
        if(fragment != null) {
            fragment.showMessage();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void btnClick(View view) {

    }
}
